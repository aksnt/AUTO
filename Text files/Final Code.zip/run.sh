#! /usr/bin/env bash

# if you're using a language other than Python 3, you will need to alter the
# following line
python3 main.py

# python, java, c, c++, haskell are supported
# for anything else, please ask staff
